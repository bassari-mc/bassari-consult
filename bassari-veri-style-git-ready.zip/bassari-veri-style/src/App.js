
import React from "react";
import { motion } from "framer-motion";
import { FaLinkedin, FaFacebook, FaInstagram } from "react-icons/fa";
import "./App.css";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans">
      <header className="bg-white text-[#0d1b2a] p-6 shadow-md">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img src="/logo.png" alt="Bassari Logo" className="h-12 w-auto" />
            <h1 className="text-2xl font-bold">Bassari MC</h1>
          </div>
          <nav className="space-x-6">
            <a href="#about" className="hover:text-[#fca311]">À propos</a>
            <a href="#services" className="hover:text-[#fca311]">Services</a>
            <a href="#competences" className="hover:text-[#fca311]">Compétences</a>
            <a href="#careers" className="hover:text-[#fca311]">Carrières</a>
            <a href="#access" className="hover:text-[#fca311]">Plan d'accès</a>
            <a href="#contact" className="hover:text-[#fca311]">Contact</a>
          </nav>
        </div>
        <motion.p 
          initial={{ opacity: 0, y: -10 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.8 }}
          className="mt-4 text-center text-[#fca311] text-lg"
        >
          Votre partenaire de confiance pour transformer les idées en résultats concrets et durables.
        </motion.p>
      </header>

      <main className="container mx-auto px-4 py-10">
        <section id="about">
          <h2 className="text-3xl font-bold mb-4">À propos de nous</h2>
          <p>Bassari Management Consulting est un cabinet de conseil spécialisé en investissement, management et stratégie...</p>
        </section>

        <section id="services" className="mt-12">
          <h2 className="text-3xl font-bold mb-4">Nos Services</h2>
          <p>Nous accompagnons les projets à forte valeur ajoutée dans divers secteurs d’activités...</p>
        </section>

        <section id="competences" className="mt-12">
          <h2 className="text-3xl font-bold mb-4">Nos Compétences</h2>
          <p>Conseil en stratégie, développement économique, ingénierie de projet, innovation, digitalisation, etc.</p>
        </section>

        <section id="careers" className="mt-12">
          <h2 className="text-3xl font-bold mb-4">Carrières</h2>
          <p>Rejoignez une équipe dynamique et engagée dans la transformation des organisations.</p>
        </section>

        <section id="access" className="mt-12">
          <h2 className="text-3xl font-bold mb-4">Plan d'accès</h2>
          <p>Nous sommes situés au cœur du centre des affaires, facilement accessible par tous les moyens de transport.</p>
        </section>

        <section id="contact" className="mt-12">
          <h2 className="text-3xl font-bold mb-4">Contact</h2>
          <form className="space-y-4">
            <input type="text" placeholder="Nom" className="border p-2 w-full" />
            <input type="email" placeholder="Email" className="border p-2 w-full" />
            <textarea placeholder="Message" className="border p-2 w-full"></textarea>
            <button type="submit" className="bg-[#fca311] text-white px-4 py-2 rounded hover:bg-[#d18b0e]">Envoyer</button>
          </form>
        </section>
      </main>

      <footer className="bg-[#f7f7f7] text-gray-700 text-center py-6 mt-12 border-t">
        <div className="flex justify-center space-x-6 mb-2">
          <a href="https://www.linkedin.com/company/bassarimc" target="_blank" rel="noopener noreferrer" className="text-[#0a66c2] text-2xl">
            <FaLinkedin />
          </a>
          <a href="https://www.facebook.com/bassarimc" target="_blank" rel="noopener noreferrer" className="text-[#1877f2] text-2xl">
            <FaFacebook />
          </a>
          <a href="https://www.instagram.com/bassarimc" target="_blank" rel="noopener noreferrer" className="text-[#e1306c] text-2xl">
            <FaInstagram />
          </a>
        </div>
        <p>&copy; 2025 Bassari Management Consulting. Tous droits réservés.</p>
      </footer>
    </div>
  );
}
